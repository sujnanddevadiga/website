let arr=[4,7,9,7];
function double(arr){
    return arr*2;
}
let output = arr.map(double);
console.log(output);

const x =[34,67,99,23];
console.log(x);
function binary(x){
    return x.toString(2);
}
const c = x.map(binary);
console.log(c);