let output = arr.map(double);
console.log(output)