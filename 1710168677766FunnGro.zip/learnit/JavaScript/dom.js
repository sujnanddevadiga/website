function changecolor(newcolor){
    const elem = document.getElementById('para');
    elem.style.color = newcolor;
}